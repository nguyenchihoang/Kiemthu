package asg06update;

 abstract public class Expression {
	abstract public String toString();
	abstract public int evalute();	
}
